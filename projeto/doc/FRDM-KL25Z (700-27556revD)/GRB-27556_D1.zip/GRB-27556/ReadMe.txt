README for GRB-27556_D1.zip

Company Part Number: 170-27556 REV D1

Date : Mon, 10 Dec 2012 21:51:17 GMT

Freescale Semiconductor
Periferico Sur #8110
Col. El Mante
Tlaquepaque, Jalisco, Mexico
C.P. 45609

Company Contact: Ricardo Cazarez
Work Phone: (52)33-32832100 Ext. 2090
Email:	 Cazarez.Ricardo@freescale.com
